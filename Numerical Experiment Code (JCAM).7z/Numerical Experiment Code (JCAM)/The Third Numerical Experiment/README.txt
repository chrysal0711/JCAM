%The numerical program for image restoration can run directly in MATLAB 2007 version. 
%However, in higher versions, you need to install compatible packages/programs on the installed 
%MATLAB version in order to run it.