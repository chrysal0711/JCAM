%% Note
%The numerical program for image restoration can run directly in MATLAB 2007 version. 
%However, in higher versions, you need to install compatible packages on the installed 
%MATLAB version in order to run it.

% This demo shows the reconstruction of a sparse image
% of randomly placed plus an minus ones
clc
clear 
close all
clf
randn('seed',1); % 1 for the experiments in the paper
addpath Images
for i = 14:14
% the test images set
A={'fruits.bmp' ,'baboon.bmp', 'brain.bmp' ,'cameraman.png', 'chart.tiff', 'peppers.bmp', 'lena.png'...
     'man.bmp', 'barbara.png', 'aa.png' , 'bb.png' , 'cc.png',  'circles.tif','bridge.bmp'};

f=double(imread(A{i})); 
[m,n] = size(f);
scrsz = get(0,'ScreenSize');
figure(1)
%set(1,'Position',[10 scrsz(4)*0.05 scrsz(3)/4 0.85*scrsz(4)])
% subplot(1,2,1)
imagesc(f)
colormap(gray(255))
axis off
axis equal
% title('Original image','FontName','Times','FontSize',22)
% title(sprintf('Original: %4d  %4d',m,n),'FontSize',22)
% create observation operator; in this case 
% it will be a blur function composed with an
% inverse weavelet transform
disp('Creating observation operator...');

middle = n/2 + 1;

% uncomment the following lines for Experiment 1 (see paper)
% sigma = 0.56;
% h = zeros(size(f));
% for i=-4:4
%    for j=-4:4
%       h(i+middle,j+middle)= 1; 
%    end
% end


% uncomment the following lines for Experiment 2 (see paper)
% sigma = sqrt(2);
sigma = sqrt(0.01);
h = zeros(size(f)); % h is the same size as f and all zeros.
for i=-4:4
   for j=-4:4
      h(i+middle,j+middle)= (1/(1+i*i+j*j));
   end
end

% uncomment the following lines for Experiment 3 (see paper)
% sigma = sqrt(8);
% h = zeros(size(f));
% for i=-4:4
%    for j=-4:4
%       h(i+middle,j+middle)= (1/(1+i*i+j*j));
%    end
% end

% % center and normalize the blur
h = fftshift(h); 
% fftshift is useful for visualizing the Fourier transform with the zero-frequency component in the middle of the spectrum.
h = h/sum(h(:));  % sum(h(:)): sum all elements of h.

% definde the function handles that compute 
% the blur and the conjugate blur.
R = @(x) real(ifft2(fft2(h).*fft2(x))); % fft2(X) returns the two-dimensional Fourier transform of matrix X.
% ifft2(F) returns the two-dimensional inverse Fourier transform of matrix F
RT = @(x) real(ifft2(conj(fft2(h)).*fft2(x)));

% define the function handles that compute 
% the products by W (inverse DWT) and W' (DWT)
wav = daubcqf(2);
W = @(x) midwt(x,wav,3);
WT = @(x) mdwt(x,wav,3);

%Finally define the function handles that compute 
% the products by A = RW  and A' =W'*R' 
A = @(x) R(W(x));
AT = @(x) WT(RT(x));

fid=fopen('mytext3.txt','a+');
% generate noisy blurred observations
y = R(f) + sigma*randn(size(f));
figure(2)
% subplot(1,2,2)
imagesc(y)
colormap(gray(255))
axis off
axis equal
% title('Blurred image','FontName','Times','FontSize',22)
% title(['Blurred: ',num2str(blur_label),'dB'],'FontName','Times','FontSize',22)

% regularization parameter
tau = .35;

% set tolA
tolA = 1.e-5;

%% PDY_CS
disp('Starting CGDESCENT_CS_image ...')
[x_CGDCS,theta_debias,obj_CGDCS,t_CGDCS,debias_CGDCS,mses_CGDCS]= ...
	PDY_CS(y,A,tau,...
	'Debias',0,...
	'AT',AT,... 
    'True_x',WT(f),...
	'Initialization',AT(y),... %0,...%
	'StopCriterion',1,...
	'ToleranceA',tolA,...
     'Verbose',0);
 SNR_CGDCS=20*log10(norm(f,'fro')/norm(f-W(x_CGDCS),'fro'));
 %PSNR_HTTCGPCS=10*log10(255*255/(mses_HTTCGPCS(end)/m/n));
 fprintf(1,'PDY_CS: Iter=%4d, obj=%10.3e, times=%6.2f, MSE=%10.4e, SNR=%6.2f\n', length(t_CGDCS),...
      obj_CGDCS(end),t_CGDCS(end),mses_CGDCS(end)/m/n,SNR_CGDCS);
  
%% ATTCGP_CS
% Run HTTCGP until the relative change in objective function is no
% larger than tolA
disp('Starting ATTCGP_CS_image ...')
[x_HTTCGPCS,theta_debias,obj_HTTCGPCS,t_HTTCGPCS,debias_HTTCGPCS,mses_HTTCGPCS]= ...
	ATTCGP_CS(y,A,tau,...
	'Debias',0,...
	'AT',AT,... 
    'True_x',WT(f),...
	'Initialization',AT(y),... %0,...%
	'StopCriterion',1,...
	'ToleranceA',tolA,...
     'Verbose',0);
 SNR_HTTCGPCS=20*log10(norm(f,'fro')/norm(f-W(x_HTTCGPCS),'fro'));
 PSNR_HTTCGPCS=10*log10(255*255/(mses_HTTCGPCS(end)/m/n));
 fprintf(1,'ATTCGPCS: Iter=%4d, obj=%10.3e, times=%6.2f, MSE=%10.4e, SNR=%6.2f\n', length(t_HTTCGPCS),...
      obj_HTTCGPCS(end),t_HTTCGPCS(end),mses_HTTCGPCS(end)/m/n,SNR_HTTCGPCS);
%   HTTCGP_label=[roundn(t_HTTCGPCS(end)) roundn(20*log10(norm(f,'fro')/norm(f-W(x_HTTCGPCS),'fro')))];
  
%% JHCGP_CS
% Run MITTCGP_CS until the relative change in objective function is no
% larger than tolA
disp('Starting MITTCGP_CS_image ...')
[x_ATTCGPCS,theta_debias,obj_ATTCGPCS,t_ATTCGPCS,debias_ATTCGPCS,mses_ATTCGPCS]= ...
	JHCGP_CS(y,A,tau,...
	'Debias',0,...
	'AT',AT,... 
    'True_x',WT(f),...
	'Initialization',AT(y),... %0,...%
	'StopCriterion',1,...
	'ToleranceA',tolA,...
     'Verbose',0);
SNR_ATTCGPCS=20*log10(norm(f,'fro')/norm(f-W(x_ATTCGPCS),'fro'));
fprintf(1,'JHCGP_CS: Iter=%4d, obj=%10.3e, times=%6.2f, MSE=%10.4e, SNR=%6.2f\n', length(t_ATTCGPCS),...
      obj_ATTCGPCS(end),t_ATTCGPCS(end),mses_ATTCGPCS(end)/m/n,SNR_ATTCGPCS);
  
%% data-write
%  ATTCGP_label=[roundn(t_ATTCGPCS(end)) roundn(20*log10(norm(f,'fro')/norm(f-W(x_ATTCGPCS),'fro')))];
fprintf(fid,'%.2f/%.2f & %.2f/%.2f & %.2f/%.2f\n', ... 
        t_CGDCS(end),SNR_CGDCS,t_HTTCGPCS(end),SNR_HTTCGPCS,t_ATTCGPCS(end),SNR_ATTCGPCS);
% i = i+1;
end
fclose(fid);
  
% % %% ================= Plotting results ==========
figure(3)
% subplot(1,5,3)
   imagesc(W(x_CGDCS))
% end
colormap(gray)
axis off
axis equal
% title(['CGD: ', num2str(CGD_label(1)),'s  ',num2str(CGD_label(2)),'dB'], 'FontName','Times','FontSize',22)
% 
figure(4)
% subplot(1,5,4)
imagesc(W(x_HTTCGPCS))
colormap(gray)
axis off
axis equal

% % 
figure(5)
% subplot(1,5,5)
imagesc(W(x_ATTCGPCS))
colormap(gray)
axis off
axis equal




