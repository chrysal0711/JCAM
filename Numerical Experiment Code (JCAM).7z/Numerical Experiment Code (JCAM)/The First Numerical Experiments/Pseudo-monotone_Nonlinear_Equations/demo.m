
% Matlab Model by Jianghua Yin (Jul.,2022,Nanning)
% Copyright (C) 2022 Jian Group
% All Rights Reserved
% Permission to use, copy, modify, and distribute this software and
% its documentation for any purpose and without fee is hereby
% granted, provided that the above copyright notice appear in all
% copies and that the copyright notice and this
% permission notice appear in all supporting documentation.      

% This is a demo of DFPM for solving constrained nonlinear pseudo-monotone equations
% equations of the form
%   F(x)=0, x\in C, 
% where C is a nonempty closed convex set.

% This MATLAB script follows the paper:
% Jian, J.B., Yin, J.H., Tang, C.M., Han, D.L.: A family of inertial derivative-free projection 
% methods for constrained nonlinear pseudo-monotone equations with
% applications. Submitted in Computational and Applied Mathematics.
%
% If you use/modify this code, please cite the just-mentioned paper appropriately.
%
% -----------------------------------------------------------------------
% Copyright (2022): Jianghua Yin
% ----------------------------------------------------------------------
%
% The first version of this code by Jianghua Yin, Dec., 16, 2019

% model=1 means -F(zk)'*dk �� sigma*tk*norm(dk)^2
% model=2 means -F(zk)'*dk �� sigma*tk*norm(F(zk))*norm(dk)^2
% model=3 means -F(zk)'*dk �� sigma*tk*norm(F(zk))/(1+norm(F(zk)))*norm(dk)^2
% model=4 means -F(zk)'*dk �� sigma*tk*max(lambda,min(nu,norm(Fz_new,2)))*norm(dk)^2

clc;
clear all
close all

% % set random number seed
% rng(2016)

ITR_max = 2000;
% setup TXT document
fid_tex=fopen('mytext10.txt','w'); 
% problem_set = 1:20;
problem_set = [1:8 15:20];  % 9 �� 11
% problem_set = [1:20];     % 9 ��10 ��11
% set parameters
np = length(problem_set); % the number of the test problems from Problem 9 to Problem 11 
ns = 3;   % the number of the test algorithms
T = zeros(np,ns);
F = zeros(np,ns);
N = zeros(np,ns);

%
para1.Itr_max = ITR_max;
para1.gamma = 0.7;         % the initial guess
para1.sigma = 0.01;         % the coefficient of line search 
para1.tau = 0.8;         % the compression ratio
para1.alpha = 0.001;       % the coefficient of inertial step
para1.rho = 1.3;         % the relaxation factor 

% set parameters for HTTCG
para2.Itr_max = ITR_max;
para2.gamma = 1;         % the initial guess
para2.sigma = 0.01;      % the coefficient of line search 
para2.tau = 0.5;         % the compression ratio
para2.rho = 1.7;         % the relaxation factor 

% set parameters for MITTCGP
% para3.Itr_max = ITR_max;
% para3.gamma = 0.4;         % the initial guess
% para3.sigma = 0.01;      % the coefficient of line search 
% para3.tau = 0.6;         % the compression ratio
% para3.rho = 1.8;         % the relaxation factor 
% para3.alpha = 0.1;       % the coefficient of inertial step

% parameters for ISTCP 1
para4.Itr_max = ITR_max;
para4.gamma = 1;         % the initial guess
para4.sigma = 0.0001;      % the coefficient of line search 
para4.tau = 0.7;         % the compression ratio
para4.rho = 1;           % the relaxation factor 
para4.alpha = 0.8;       % the coefficient of inertial step
% run
for index=1:np
    Num = problem_set(index);
    [name,x0] = init(Num);

    [T1,NFF1,NI1,G1] = Copy_of_IDFPM(Num,'JHCGPM',1,5,x0,para1); % acceleration
    [T2,NFF2,NI2,G2] = UIDFPM(Num,'HTTCG',2,x0,para2);
   % [T3,NFF3,NI3,G3] = IDFPM(Num,'MITTCGP',1,5,x0,para3);
    [T4,NFF4,NI4,G4] = IDFPM(Num,'ISTCP',1,1,x0,para4);
    fprintf(fid_tex,'%s & %d/%d/%.3f/%.2e & %d/%d/%.3f/%.2e  & %d/%d/%.3f/%.2e\\\\ \r\n', ... 
                name,NI1,NFF1,T1,G1,NI2,NFF2,T2,G2,NI4,NFF4,T4,G4);
    T(index,:) = [T1,T2,T4];
    F(index,:) = [NFF1,NFF2,NFF4];
    N(index,:) = [NI1,NI2,NI4];
    %G(index,:) = [G1,G2,G3];
end
%% �ر��ļ�
fclose(fid_tex);