% Matlab Model by Zefeng Huang (Dec.,2021,Nanning)
% Copyright (C) 2023 Jian Group
% All Rights Reserved
% jia su 
%% Derivative-Free Projection Method

% NO=1;
% method='PRP+';
 function [Tcpu,NF,Itr,NG] = MITTCGP(NO,method,x0) 
format long
Step=0:4;  % ����һ��5ά��������0,1,2,3,4��
nextstep=Step(1);
% disp(date);
finish=0;
Itr=0;  %% ����
NF=1;   %% Ŀ�꺯���������
%NP=1;  %% ͶӰ�������
tic     %% ��ʼ��ʱ��
while finish==0
    loop=1;
    while loop==1
        switch nextstep
            case Step(1)
                % k=1;
                %% Step 0 ��ʼ�� ��������
                %% ���ó�ʼ��
%                 [nprob,n,x0,x2]=init2(NO);  % ����ļ��޸�
%                 [nprob,n,x0]=init(NO);  % ����ļ��޸�
                x2 = x0;
                [nprob,n]=init(NO);
                epsilon=1e-6;
                epsilon1=1e-7;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���Բ���   %�˴������µĶ�������Ҫ�ͽ���ʦ�ֵıȽ�
                alpha=0.01; %���Բ����ĸ�������
                gammak = 1; %��ʼ���ļ�������Ϊ1 
                corr = 1.3; %У������
                %k=1;
                alphak0=min(alpha,1/((Itr^2)*norm(x0-x2,2)));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %% ����������
                sigma=0.01;  % sigma=0.01
                gamma=0.4;   % gamma=1, initial guess for the steplength
                rho=0.5;    % rho=0.9
                %% ��ʼ����
%                 Fk=feval(nprob,n,x0,1);  % feval��n,x0��ֵ��һ������õĺ���nprob������1��
%                 dk=(-1)*Fk;

%                 x00=x0+alphak0*(x0-x2); %��ʼ����
%                 %%% v_k = x_k + lambda_k * (x_k - x_k-1)
%                 Fk=feval(nprob,n,x00,1);
                x0=x0+alphak0*(x0-x2); %��ʼ����
                %%% v_k = x_k + lambda_k * (x_k - x_k-1)
                Fk=feval(nprob,n,x0,1);
                dk=(-1)*Fk;  %�ٽ���������ǰ�ĳ�ʼ����
                nextstep=Step(2);
%               tic;
            case Step(2)
                %% Step 1 ��ֹ׼���������
                if  norm(Fk,2)<=epsilon || Itr>2000  %����ѭ��
                    nextstep=Step(5);  % ����
                    break;
                else  % ������
                 %% Start Armijo-type line search  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    t =gamma;  % initial steplength
                    L1=1;
                    while L1==1
                        z_new=x0+t*dk;
                        Fz_new=feval(nprob,n,z_new,1);
                        NF=NF+1;
                        eta_k=max(0.001,min(0.8,norm(Fz_new,2))); %norm(Fz_new,2)/(1+norm(Fz_new,2)); % 0.001,8 
                      %% check the Armijo-type line search condition
                        if (-Fz_new'*dk < sigma*t*eta_k*norm(dk,2)^2 && t>10^(-10))  % the Armijo-type line search condition violated
                            L1=1;
                            t=t*rho;
                        else
                            L1=0;
                        end
                    end       % ��ֹwhile L1==1
                 %% End Armijo-type line search %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    zk=x0+t*dk;  % zk=z_new;
                    Fzk= feval(nprob,n,zk,1);  %  Fzk=Fz_new;
                end  % ��ֹ if norm(Fk,2)<=epsilon || Itr>2000  
                nextstep=Step(3);
            case Step(3)
                xik=Fzk'*(x0-zk)/norm(Fzk)^2;
                %%%% �˴�����ط��ͱ�ʾ���ɳ���
                zk1=x0-1.8*xik*Fzk;     % �˴�ͨ����ͶӰ��ϵ����1��
                x1=feval(nprob,n,zk1,2);     % ͶӰ�õ��µĵ�����x_{k+1}
                %NP=NP+1;
                Fk0=Fk;
                Fk=feval(nprob,n,x1,1);   % �����µĺ���ֵF_{k+1}
                NF=NF+1;
                nextstep=Step(4);
            case Step(4)
                %% Step 2 ���¼�����Ժ���һ��dk
                Itr=Itr+1;
%               Fk0=feval(nprob,n,x0,1);
                sk=x1-x0;
                yk=Fk-Fk0;
                %����λ��
%                 gammak = -(norm(yk)^2)/(corr*t*gammak^(-1)*(yk'*Fk));
                %%%%%% �����漸�о��Ǳ�ʾ���ԣ��˴��뽭��ʦ�ֵ���Щ��ͬ
                %%%��ֵ���ֵ�Ĳ�� �ĸ��ã�

                switch method
                    case 'JJC'
                        tk=1+max(0,-dk'*yk/norm(dk)^2);
                        wk=yk+tk*dk;
                        Tk=min(0.4,max(0,1-yk'*sk/norm(yk)^2)); % yk1=yk+0.01*dk����ֵЧ��û��ֱ��ʹ��ykЧ����
                        mu=0.1;
                        fenmu=max(norm(Fk0)^2,max(mu*norm(dk)*norm(wk),dk'*wk));
                        thetak=Tk*Fk'*dk/fenmu;  % ԭʼ�ķ�ĸ�� norm(Fk0)^2
                        betak=Fk'*wk/fenmu-norm(wk)^2*Fk'*dk/fenmu^2; %(max(mu*norm(dk)*norm(Fk),norm(Fk0)^2))
                        dk=-Fk+betak*dk+thetak*wk;
                        %%
                    case 'HZF'
                        vv = 1.5;
                        
                        %�������� gammak 
                        numerator = abs(Fk'*yk);
                        denominator = max(abs(Fk'*dk),vv*norm(dk)*norm(yk));
                        betak = numerator/denominator;
                        numer = norm(Fk)^2*(1-corr*gammak^(-1))-betak*(Fk'*dk);
                        denominatorp = Fk'*dk;
                        thetak = numer/denominatorp;
%                         dk=-Fk+betak*dk+thetak*pk;
                        dk=-Fk+betak*dk+thetak*dk; %�˴�pk����
                        %%
                    case 'HTTCGN'  %Ч������
                        %                         yk0=Fzk-Fk0;
                        lambdak=1+max(0,-yk'*sk/(norm(Fk)*norm(sk)^2));
                        yk1=yk+lambdak*norm(Fk)*sk;
                        tk=min(0.3,max(0,1-yk'*sk/norm(yk)^2)); % yk1=yk+0.01*dk����ֵЧ��û��ֱ��ʹ��ykЧ����
                        mu=0.2;
                        fenmu=max(norm(Fk0)^2,max(mu*norm(dk)*norm(yk1),dk'*yk1));
                        thetak=tk*Fk'*dk/fenmu;  % ԭʼ�ķ�ĸ�� norm(Fk0)^2
                        betak=Fk'*yk1/fenmu-norm(yk1)^2*Fk'*dk/fenmu^2; %(max(mu*norm(dk)*norm(Fk),norm(Fk0)^2))
                        dk=-Fk+betak*dk+thetak*yk1;
                    case'MMNEW'  % Ч��ûMNEWP��MNEW��
                        yk1=yk+0.01*sk;
                        tk=min(0.3,max(0,1-yk1'*sk/norm(yk1)^2));
                        mu=0.5;   % ��ֵЧ������ mu=0.2
                        fenmu=max(mu*norm(sk)*norm(yk),sk'*yk);
                        thetak=tk*Fk'*sk/fenmu;  % ԭʼ�ķ�ĸ�� norm(Fk0)^2
                        betak=Fk'*yk1/fenmu-norm(yk1)^2*Fk'*sk/fenmu^2; %(max(mu*norm(dk)*norm(Fk),norm(Fk0)^2))
                        dk=-Fk+betak*sk+thetak*yk1;
                    case 'PDY' %Liu J.K.,Feng Y.M.,(2018)A derivative-free iterative method for nonlinear monotone
                        %equations with convex constraints,Numerical Algorithms
                        tk=1+max(0,-dk'*yk/norm(dk)^2);
                        wk=yk+tk*dk;
                        betak=norm(Fk)^2/(dk'*wk);
                        c=1;
                        thetak=c-Fk'*dk/(dk'*wk);
                        dk=-thetak*Fk+betak*dk;
                    case 'TPRP' %2015 A three-terms Polak�CRibi��re�CPolyak conjugate gradient algorithm for large-scale nonlinear equations
                        mu=0.01;
                        dk=-Fk+(Fk'*yk*dk-Fk'*dk*yk)/max(mu*norm(dk)*norm(yk),norm(Fk0)^2);
                    case 'IDFPI'
                        beltk=0.01*norm(Fk)/norm(dk);
                        dk=-(1+beltk*Fk'*dk/(norm(Fk)^2))*Fk+beltk*dk;
                    case 'WYL'
                        betak=Fk'*(Fk-norm(Fk)/norm(Fk0)*Fk0)/norm(Fk0)^2; % WYL
                        dk=-1*Fk+betak*dk;
                    case 'PRP+'
                        betak=max(0,Fk'*(Fk-Fk0)/norm(Fk0)^2);
                        dk=-1*Fk+betak*dk;
                    case 'NN'
                        %Sun M, Liu J. New hybrid conjugate gradient projection method for the convex constrained equations[J].
                        %Calcolo, 2016, 53(3): 399-411.
                        mu=1.4;
                        betak=(norm(Fk)^2-max(0,norm(Fk)/norm(Fk0)*Fk'*Fk0))/max(mu*norm(dk)*norm(Fk),dk'*yk);
                        dk=-1*Fk+betak*dk;
                    case 'MNN'
                        mu=1.4;
                        betak=(norm(Fk)^2-max(0,norm(Fk)/norm(Fk0)*Fk'*Fk0))/(max(mu*norm(dk)*norm(Fk),-dk'*Fk0));%max(norm(Fk0)^2,
                        dk=-1*Fk+betak*dk;
                    case 'MN'
                        mu=1.4;
                        betak=(norm(Fk)^2-max(Fk'*Fk0,max(0,norm(Fk)/norm(Fk0)*Fk'*Fk0)))/(max(mu*norm(dk)*norm(Fk),norm(Fk0)^2));%dk'*yk));
                        dk=-1*Fk+betak*dk;
                    case 'YJH'
                        mu=1.4;
                        betak=(norm(Fk)^2-max(0,norm(Fk)/norm(Fk0)*Fk'*Fk0))/max(mu*norm(dk)*norm(Fk),dk'*yk);
                        dk=-(1+betak*Fk'*dk/norm(Fk)^2)*Fk+betak*dk;
                    case 'JYJ' %ͶJCAMʹ�õĹ������
                        mu=1.4;
                        betak=min(abs(Fk'*(Fk-Fk0))/norm(Fk0)^2,(norm(Fk)^2-norm(Fk)/norm(Fk0)*Fk'*Fk0)/(2*mu*norm(dk)*norm(Fk)));
                        dk=-1*Fk+betak*dk;
                    case 'IFR'
                        betak=abs(Fk'*dk)/(-Fk0'*dk)*norm(Fk)^2/norm(Fk0)^2;
                        dk=-1*Fk+betak*dk;
                    case 'YLS'
                        r=0.01;
                        yk1=yk+r*sk;
                        thetak=norm(sk)^2/(sk'*yk1);
                        dk=-1*thetak*Fk;
                    case'MNEWP' %�ο��� Li M. A three term Polak-Ribi��re-Polyak conjugate gradient method close to the
                        %memoryless BFGS quasi-Newton method, Journal of Industrial & Management Optimization, 2018.
                        tk=min(0.3,max(0,1-yk'*sk/norm(yk)^2));
                        mu=0.2;   % ��ֵЧ������ mu=0.2
                        thetak=tk*Fk'*dk/max(norm(Fk0)^2,max(mu*norm(dk)*norm(yk),dk'*yk));  % ԭʼ�ķ�ĸ�� norm(Fk0)^2
                        betak=Fk'*yk/max(norm(Fk0)^2,max(mu*norm(dk)*norm(yk),dk'*yk))-norm(yk)^2*Fk'*dk/(max(norm(Fk0)^2,max(mu*norm(dk)*norm(yk),dk'*yk)))^2; %max(mu*norm(dk)*norm(yk),dk'*yk)
                        dk=-Fk+betak*dk+thetak*yk;
                    case 'MNEW'
                        yk1=yk+0.01*dk;
                        tk=min(0.3,max(0,1-yk1'*sk/norm(yk1)^2));
                        mu=0.2;   % ��ֵЧ������ mu=0.2
                        fenmu=max(mu*norm(dk)*norm(yk1),dk'*yk1);
                        thetak=tk*Fk'*dk/fenmu;  % ԭʼ�ķ�ĸ�� norm(Fk0)^2
                        betak=Fk'*yk1/fenmu-norm(yk1)^2*Fk'*dk/fenmu^2; %(max(mu*norm(dk)*norm(Fk),norm(Fk0)^2))
                        dk=-Fk+betak*dk+thetak*yk1;
                    case 'HTTCG'
                        tk=min(0.3,max(0,1-yk'*sk/norm(yk)^2)); % yk1=yk+0.01*dk����ֵЧ��û��ֱ��ʹ��ykЧ����
                        mu=0.2;
                        fenmu=max(norm(Fk0)^2,max(mu*norm(dk)*norm(yk),dk'*yk));
                        thetak=tk*Fk'*dk/fenmu;  % ԭʼ�ķ�ĸ�� norm(Fk0)^2
                        betak=Fk'*yk/fenmu-norm(yk)^2*Fk'*dk/fenmu^2; %(max(mu*norm(dk)*norm(Fk),norm(Fk0)^2))
                        dk=-Fk+betak*dk+thetak*yk;
                end
                gammak = -(norm(yk)^2)/(corr*t*gammak^(-1)*(yk'*Fk));
                x2=x0;  %�˴�ֻҪdk��д����x��� Ҳ������ȷ
                x0=x1;
                alphak=min(alpha,1/((Itr^2)*norm(x0-x2,2)));
                x0=x0+alphak*(x0-x2);
                Fk=feval(nprob,n,x0,1);
                
                if norm(dk)<epsilon1
                    nextstep=Step(5);
                    break;
                end
                
                nextstep=Step(2);
            case Step(5)
                loop=0;
%                 finish=1;
%                 break;
        end
    end
    if Itr>=2001 %|| norm(gk,2)>epsilon || isnan(Itr)==1  || abs(t)<epsilon  norm(gk,2)>epsilon 
      Tcpu=NaN;
      NF=NaN;
      Itr=NaN;
      NG=NaN;
    else
      Tcpu=toc; 
      NG=norm(Fk);
    end
    finish=1;
%      Tcpu=toc;
end
% [Tcpu Itr NF norm(Fk) norm(dk)]
%Tcpu=cputime-t0;
