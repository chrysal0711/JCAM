%% Derivative-Free Projection Method
 function [Tcpu,NF,Itr,NG] = Copy_3_of_MITTCGP(NO,method,x0) 
format long
Step=0:4;  % ����һ��5ά��������0,1,2,3,4��
nextstep=Step(1);
% disp(date);
finish=0;
Itr=0;  %% 
NF=1;   %% 
tic     %% 
while finish==0
    loop=1;
    while loop==1
        switch nextstep
            case Step(1)
                % k=1;
                %% Step 0 ��ʼ�� ��������
                %% ���ó�ʼ��
%                 [nprob,n,x0,x2]=init2(NO); 
                [nprob,n]=init(NO);  
                x2 = x0;
%                 [nprob,n]=init(NO);
                epsilon=1e-6;
                epsilon1=1e-7;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                alpha=0.001; %
                gammak = 1; % 
                corr = 1.3; %
                alphak0=min(alpha,1/((Itr^2)*norm(x0-x2,2)));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %% ����������
                sigma=0.01;  % sigma=0.01
                gamma=0.7;   % gamma=1, initial guess for the steplength
                rho=0.4;     % rho=0.9 
                %% ��ʼ����
%                 Fk=feval(nprob,n,x0,1);  %
%                 dk=(-1)*Fk;

%                 x00=x0+alphak0*(x0-x2); %��ʼ����
%                 %%% v_k = x_k + lambda_k * (x_k - x_k-1)
%                 Fk=feval(nprob,n,x00,1);
                x0=x0+alphak0*(x0-x2); %
                %%% v_k = x_k + lambda_k * (x_k - x_k-1)
                Fk=feval(nprob,n,x0,1);
                dk=(-1)*Fk;  %
                nextstep=Step(2);
%               tic;
            case Step(2)
                %% Step 1 
                if  norm(Fk,2)<=epsilon || Itr>2000  
                    nextstep=Step(5);  
                    break;
                else  % ������
                 %% Start Armijo-type line search  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    t =gamma;  % initial steplength
                    L1=1;
                    while L1==1
                        z_new=x0+t*dk;
                        Fz_new=feval(nprob,n,z_new,1);
                        NF=NF+1;
                        eta_k=max(0.001,min(0.8,norm(Fz_new,2))); %norm(Fz_new,2)/(1+norm(Fz_new,2)); % 0.001,8 
                      %% check the Armijo-type line search condition
                        if (-Fz_new'*dk < sigma*t*eta_k*norm(dk,2)^2 && t>10^(-10))  % the Armijo-type line search condition violated
                            L1=1;
                            t=t*rho;
                        else
                            L1=0;
                        end
                    end       % ��ֹwhile L1==1
                 %% End Armijo-type line search %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    zk=x0+t*dk;  % zk=z_new;
                    Fzk= feval(nprob,n,zk,1);  %  Fzk=Fz_new;
                end  % ��ֹ if norm(Fk,2)<=epsilon || Itr>2000  
                nextstep=Step(3);
            case Step(3)
                xik=Fzk'*(x0-zk)/norm(Fzk)^2;
                %%%% 
                zk1=x0-1.9*xik*Fzk;    
                x1=feval(nprob,n,zk1,2);    
                %NP=NP+1;
                Fk0=Fk;
                Fk=feval(nprob,n,x1,1);   %
                NF=NF+1;
                nextstep=Step(4);
            case Step(4)
                %% Step 2 
                Itr=Itr+1;
%               Fk0=feval(nprob,n,x0,1);
                sk=x1-x0;
                yk=Fk-Fk0;

                switch method

                      case 'HZF3'
                        vv = 1.8;
                        numerator = abs(Fk'*yk);
                        denominator = max(abs(Fk'*dk),vv*norm(dk)*norm(yk));
                        betak = numerator/denominator;
                        numer = norm(Fk)^2*(1-corr*gammak^(-1))-betak*(Fk'*dk);
                        denominatorp = Fk'*dk;
                        thetak = numer/denominatorp;
                        ll = 0.5;rr = 0.8;kkk = 0.01;
                        if -ll*norm(Fk)^2<=betak*(Fk'*dk)&&betak*(Fk'*dk)>=rr*norm(Fk)^2
                             dk=-Fk+betak*dk+thetak*Fk; 
                        else
                             dk=-Fk+kkk*(Fk'*yk)*yk/norm(yk)^2; 
                        end
                        %%
                    case 'HTTCGN'  %Ч������
                        %                         yk0=Fzk-Fk0;
                        lambdak=1+max(0,-yk'*sk/(norm(Fk)*norm(sk)^2));
                        yk1=yk+lambdak*norm(Fk)*sk;
                        tk=min(0.3,max(0,1-yk'*sk/norm(yk)^2)); % yk1=yk+0.01*dk����ֵЧ��û��ֱ��ʹ��ykЧ����
                        mu=0.2;
                        fenmu=max(norm(Fk0)^2,max(mu*norm(dk)*norm(yk1),dk'*yk1));
                        thetak=tk*Fk'*dk/fenmu;  % ԭʼ�ķ�ĸ�� norm(Fk0)^2
                        betak=Fk'*yk1/fenmu-norm(yk1)^2*Fk'*dk/fenmu^2; %(max(mu*norm(dk)*norm(Fk),norm(Fk0)^2))
                        dk=-Fk+betak*dk+thetak*yk1;
                    case 'PDY' %Liu J.K.,Feng Y.M.,(2018)A derivative-free iterative method for nonlinear monotone
                        %equations with convex constraints,Numerical Algorithms
                        tk=1+max(0,-dk'*yk/norm(dk)^2);
                        wk=yk+tk*dk;
                        betak=norm(Fk)^2/(dk'*wk);
                        c=1;
                        thetak=c-Fk'*dk/(dk'*wk);
                        dk=-thetak*Fk+betak*dk;
                    case 'TPRP' %2015 A three-terms Polak�CRibi��re�CPolyak conjugate gradient algorithm for large-scale nonlinear equations
                        mu=0.01;
                        dk=-Fk+(Fk'*yk*dk-Fk'*dk*yk)/max(mu*norm(dk)*norm(yk),norm(Fk0)^2);
                    case 'IDFPI'
                        beltk=0.01*norm(Fk)/norm(dk);
                        dk=-(1+beltk*Fk'*dk/(norm(Fk)^2))*Fk+beltk*dk;
                    case 'WYL'
                        betak=Fk'*(Fk-norm(Fk)/norm(Fk0)*Fk0)/norm(Fk0)^2; % WYL
                        dk=-1*Fk+betak*dk;
                    case 'PRP+'
                        betak=max(0,Fk'*(Fk-Fk0)/norm(Fk0)^2);
                        dk=-1*Fk+betak*dk;
                    case 'HTTCG'
                        tk=min(0.3,max(0,1-yk'*sk/norm(yk)^2)); % yk1=yk+0.01*dk����ֵЧ��û��ֱ��ʹ��ykЧ����
                        mu=0.2;
                        fenmu=max(norm(Fk0)^2,max(mu*norm(dk)*norm(yk),dk'*yk));
                        thetak=tk*Fk'*dk/fenmu;  % ԭʼ�ķ�ĸ�� norm(Fk0)^2
                        betak=Fk'*yk/fenmu-norm(yk)^2*Fk'*dk/fenmu^2; %(max(mu*norm(dk)*norm(Fk),norm(Fk0)^2))
                        dk=-Fk+betak*dk+thetak*yk;
                end
               
                gammak = -(norm(yk)^2)/(corr*t*gammak^(-1)*(yk'*Fk));
                if gammak<=1e-6
                    gammak = 1;
                end
                if gammak>=1e+6
                    gammak = 1e+6;
                end
                x2=x0;  %
                x0=x1;
                alphak=min(alpha,1/((Itr^2)*norm(x0-x2,2)));
                x0=x0+alphak*(x0-x2);
                Fk=feval(nprob,n,x0,1);
                
                if norm(dk)<epsilon1
                    nextstep=Step(5);
                    break;
                end
                
                nextstep=Step(2);
            case Step(5)
                loop=0;
%                 finish=1;
%                 break;
        end
    end
    if Itr>=2001 %|| norm(gk,2)>epsilon || isnan(Itr)==1  || abs(t)<epsilon  norm(gk,2)>epsilon 
      Tcpu=NaN;
      NF=NaN;
      Itr=NaN;
      NG=NaN;
    else
      Tcpu=toc; 
      NG=norm(Fk);
    end
    finish=1;
%      Tcpu=toc;
end

