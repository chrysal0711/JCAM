% init 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [nprob,n,m,x0]=initf(nprob)
% This function sets n,m, and the standard starting    
% point based on the nprob and returns it to initpt     
% function.                                                                                                    
% Created on 10/30/94 by Madhu Lamba                   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [nprob,n] = init(NO)

%global FIRSTIME

switch NO
    %% nprob='problem1'; cuter
      case 1
        nprob='problem1';
        n=10000;
%         x0=ones(n,1);
    
    %% nprob='problem1'; cuter
      case 2
        nprob='problem1';
        n=30000;
%         x0=0.1*ones(n,1);
        
    %% nprob='problem1'; cuter
      case 3
        nprob='problem1';
        n=50000;
%         x0=ones(n,1);
%         x0(1)=0.5;
%         for i=1:n-1
%             x0(i+1)=0.5*x0(i);
%         end
        
    %% nprob='problem1'; cuter
      case 4
        nprob='problem1';
        n=80000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=(i-1)/n;
%         end
    
    %% nprob='problem1'; cuter
      case 5
        nprob='problem1';
        n=100000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=1/i;
%         end
        
%     %% nprob='problem1'; cuter
%       case 6
%         nprob='problem1';
%         n=30000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=i/n;
% %         end
%         
%     %% nprob='problem1'; cuter
%       case 7
%         nprob='problem1';
%         n=50000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=1-i/n;
% %         end
%     
%     %% nprob='problem1'; cuter
%       case 8
%         nprob='problem1';
%         n=80000;
% %         x0=ones(n,1);
%     
%     %% nprob='problem1'; cuter
%       case 9
%         nprob='problem1';
%         n=100000;
% %         x0=0.1*ones(n,1);
        
    %% nprob='problem2'; cuter
      case 6%10
        nprob='problem2';
        n=10000;
%         x0=ones(n,1);
    
    %% nprob='problem2'; cuter
      case 7%11
        nprob='problem2';
        n=30000;
%         x0=0.1*ones(n,1);
        
    %% nprob='problem2'; cuter
      case 8%12
        nprob='problem2';
        n=50000;
%         x0=ones(n,1);
%         x0(1)=0.5;
%         for i=1:n-1
%             x0(i+1)=0.5*x0(i);
%         end
        
    %% nprob='problem2'; cuter
      case 9%13
        nprob='problem2';
        n=80000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=(i-1)/n;
%         end
    
    %% nprob='problem2'; cuter
      case 10%14
        nprob='problem2';
        n=100000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=1/i;
%         end
        
%     %% nprob='problem2'; cuter
%       case 15
%         nprob='problem2';
%         n=30000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=i/n;
% %         end
%         
%     %% nprob='problem2'; cuter
%       case 16
%         nprob='problem2';
%         n=50000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=1-i/n;
% %         end
%     
%     %% nprob='problem2'; cuter
%       case 17
%         nprob='problem2';
%         n=80000;
% %         x0=ones(n,1);
%     
%     %% nprob='problem2'; cuter
%       case 18
%         nprob='problem2';
%         n=100000;
% %         x0=0.1*ones(n,1);

    %% nprob='problem3'; cuter
      case 11%19
        nprob='problem3';
        n=10000;
%         x0=ones(n,1);
    
    %% nprob='problem3'; cuter
      case 12%20
        nprob='problem3';
        n=30000;
%         x0=0.1*ones(n,1);
        
    %% nprob='problem3'; cuter
      case 13%21
        nprob='problem3';
        n=50000;
%         x0=ones(n,1);
%         x0(1)=0.5;
%         for i=1:n-1
%             x0(i+1)=0.5*x0(i);
%         end
        
    %% nprob='problem3'; cuter
      case 14%22
        nprob='problem3';
        n=80000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=(i-1)/n;
%         end
    
    %% nprob='problem3'; cuter
      case 15%23
        nprob='problem3';
        n=100000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=1/i;
%         end
        
%     %% nprob='problem3'; cuter
%       case 24
%         nprob='problem3';
%         n=30000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=i/n;
% %         end
%         
%     %% nprob='problem3'; cuter
%       case 25
%         nprob='problem3';
%         n=50000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=1-i/n;
% %         end
%     
%     %% nprob='problem3'; cuter
%       case 26
%         nprob='problem3';
%         n=80000;
% %         x0=ones(n,1);
%     
%     %% nprob='problem3'; cuter
%       case 27
%         nprob='problem3';
%         n=100000;
% %         x0=0.1*ones(n,1);

    %% nprob='problem4'; cuter
      case 16%28
        nprob='problem4';
        n=10000;
%         x0=ones(n,1);
    
    %% nprob='problem4'; cuter
      case 17%29
        nprob='problem4';
        n=30000;
%         x0=0.1*ones(n,1);
        
    %% nprob='problem4'; cuter
      case 18%30
        nprob='problem4';
        n=50000;
%         x0=ones(n,1);
%         x0(1)=0.5;
%         for i=1:n-1
%             x0(i+1)=0.5*x0(i);
%         end
        
    %% nprob='problem4'; cuter
      case 19%31
        nprob='problem4';
        n=80000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=(i-1)/n;
%         end
    
    %% nprob='problem4'; cuter
      case 20%32
        nprob='problem4';
        n=100000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=1/i;
%         end
        
%     %% nprob='problem4'; cuter
%       case 33
%         nprob='problem4';
%         n=30000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=i/n;
% %         end
%         
%     %% nprob='problem4'; cuter
%       case 34
%         nprob='problem4';
%         n=50000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=1-i/n;
% %         end
%     
%     %% nprob='problem4'; cuter
%       case 35
%         nprob='problem4';
%         n=80000;
% %         x0=ones(n,1);
%     
%     %% nprob='problem4'; cuter
%       case 36
%         nprob='problem4';
%         n=100000;
% %         x0=0.1*ones(n,1);

    %% nprob='problem5'; cuter
      case 21%37
        nprob='problem5';
        n=10000;
%         x0=ones(n,1);
    
    %% nprob='problem5'; cuter
      case 22%38
        nprob='problem5';
        n=30000;
%         x0=0.1*ones(n,1);
        
    %% nprob='problem5'; cuter
      case 23%39
        nprob='problem5';
        n=50000;
%         x0=ones(n,1);
%         x0(1)=0.5;
%         for i=1:n-1
%             x0(i+1)=0.5*x0(i);
%         end
        
    %% nprob='problem5'; cuter
      case 24%40
        nprob='problem5';
        n=80000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=(i-1)/n;
%         end
    
    %% nprob='problem5'; cuter
      case 25%41
        nprob='problem5';
        n=100000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=1/i;
%         end
        
%     %% nprob='problem5'; cuter
%       case 42
%         nprob='problem5';
%         n=30000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=i/n;
% %         end
%         
%     %% nprob='problem5'; cuter
%       case 43
%         nprob='problem5';
%         n=50000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=1-i/n;
% %         end
%     
%     %% nprob='problem5'; cuter
%       case 44
%         nprob='problem5';
%         n=80000;
% %         x0=ones(n,1);
%     
%     %% nprob='problem5'; cuter
%       case 45
%         nprob='problem5';
%         n=100000;
% %         x0=0.1*ones(n,1);

    %% nprob='problem6'; cuter
      case 26%46
        nprob='problem6';
        n=10000;
%         x0=ones(n,1);
    
    %% nprob='problem6'; cuter
      case 27%47
        nprob='problem6';
        n=30000;
%         x0=0.1*ones(n,1);
        
    %% nprob='problem6'; cuter
      case 28%48
        nprob='problem6';
        n=50000;
%         x0=ones(n,1);
%         x0(1)=0.5;
%         for i=1:n-1
%             x0(i+1)=0.5*x0(i);
%         end
        
    %% nprob='problem6'; cuter
      case 29%49
        nprob='problem6';
        n=80000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=(i-1)/n;
%         end
    
    %% nprob='problem6'; cuter
      case 30%50
        nprob='problem6';
        n=100000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=1/i;
%         end
        
%     %% nprob='problem6'; cuter
%       case 51
%         nprob='problem6';
%         n=30000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=i/n;
% %         end
%         
%     %% nprob='problem6'; cuter
%       case 52
%         nprob='problem6';
%         n=50000;
% %         x0=ones(n,1);
% %         for i=1:n
% %             x0(i)=1-i/n;
% %         end
%     
%     %% nprob='problem6'; cuter
%       case 53
%         nprob='problem6';
%         n=80000;
% %         x0=ones(n,1);
%     
%     %% nprob='problem6'; cuter
%       case 54
%         nprob='problem6';
%         n=100000;
% %         x0=0.1*ones(n,1);

    %% nprob='problem7'; cuter
      case 31%46
        nprob='problem7';
        n=10000;
%         x0=ones(n,1);
    
    %% nprob='problem7'; cuter
      case 32%47
        nprob='problem7';
        n=30000;
%         x0=0.1*ones(n,1);
        
    %% nprob='problem7'; cuter
      case 33%48
        nprob='problem7';
        n=50000;
%         x0=ones(n,1);
%         x0(1)=0.5;
%         for i=1:n-1
%             x0(i+1)=0.5*x0(i);
%         end
        
    %% nprob='problem7'; cuter
      case 34%49
        nprob='problem7';
        n=80000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=(i-1)/n;
%         end
    
    %% nprob='problem7'; cuter
      case 35%50
        nprob='problem7';
        n=100000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=1/i;
%         end

%% nprob='problem8'; cuter
      case 36%46
        nprob='problem8';
        n=10000;
%         x0=ones(n,1);
    
    %% nprob='problem8'; cuter
      case 37%47
        nprob='problem8';
        n=30000;
%         x0=0.1*ones(n,1);
        
    %% nprob='problem8'; cuter
      case 38%48
        nprob='problem8';
        n=50000;
%         x0=ones(n,1);
%         x0(1)=0.5;
%         for i=1:n-1
%             x0(i+1)=0.5*x0(i);
%         end
        
    %% nprob='problem8'; cuter
      case 39%49
        nprob='problem8';
        n=80000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=(i-1)/n;
%         end
    
    %% nprob='problem8'; cuter
      case 40%50
        nprob='problem8';
        n=100000;
%         x0=ones(n,1);
%         for i=1:n
%             x0(i)=1/i;
%         end

end