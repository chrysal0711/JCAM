% Matlab Model by Jianghua Yin (Dec.,2019,Nanning)
% Copyright (C) 2019 Jian Group
% All Rights Reserved
% Permission to use, copy, modify, and distribute this software and
% its documentation for any purpose and without fee is hereby
% granted, provided that the above copyright notice appear in all
% copies and that the copyright notice and this
% permission notice appear in all supporting documentation.  

% This is a demo of HTTCGP method for solving the following constrained
% nonlinear monotone equations
% F(x)=0, x\in C
% where C is a nonempty closed convex set.

% using the algorithm modified three-term conjugate gradient projection method, described in the following paper
%
% -----------------------------------------------------------------------
% Copyright (2019): Jianghua Yin
% ----------------------------------------------------------------------
%
% The first version of this code by Jianghua Yin, Dec., 16, 2019
clear all
close all
clc
format long   
format compact
% set parameter
% rand(2)
% setup TXT document
fid_tex=fopen('mytext11.txt','w'); 
% parameter
ns=2;     % number of the test algorithms
T=zeros(np,ns);
F=zeros(np,ns);
N=zeros(np,ns);%G=zeros(np,ns);
for index=1:40
    index
    [name,n]=Copy_of_init(index);
    progress_r=[];
    for repeats=1:2
        x0 = 2*rand(n,1)-1;
        [T1,NFF1,NI1,G1] = Copy_3_of_MITTCGP(index,'HZF3',x0); % acceleration
        [T2,NFF2,NI2,G2] = Copy_3_of_MITTCGP_UA(index,'HZF3',x0);
        progress_r=[progress_r;NI1,NFF1,T1,G1,NI2,NFF2,T2,G2];
    end
    fprintf(fid_tex,'%s %d & %.0f/%.0f/%.3f/%.2e & %.0f/%.0f/%.3f/%.2e \n', ... 
                name,n,mean(progress_r));
    TM = mean(progress_r);
    T(index,:) = [TM(3),TM(7)]; 
    F(index,:) = [TM(2),TM(6)];
    N(index,:) = [TM(1),TM(5)]; 
    %G(index,:) = [TM(4),TM(8),TM(12),TM(16)]; 
end
%% �ر��ļ�
fclose(fid_tex);

%% ��ͼ
clf;  
       
figure(1);
%subplot(2,2,1);
perf(T,'logplot');
%set(gca,'ylim',[0.3,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
legend('JHCGPM' ,'JHCGPM-UI'); 
%subplot(2,2,2);
figure(2);
perf(F,'logplot');
% set(gca,'ylim',[0.1,1]);
xlabel('\tau','Interpreter','tex');                   
ylabel('\rho(\tau)','Interpreter','tex');             
legend('JHCGPM' ,'JHCGPM-UI');
%subplot(2,2,3);
figure(3);
perf(N,'logplot');
%title('������������');
%set(gca,'ylim',[0.5,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
legend('JHCGPM' ,'JHCGPM-UI');